<?php

namespace App\Controllers\Api;

use App\Models\BookingModel;
use App\Models\SessionModel;
use App\Models\PhotoModel;
use App\Services\GoogleDriveService;
use App\Services\EmailService;
use CodeIgniter\HTTP\ResponseInterface;

class SessionController extends BaseApiController
{
    private BookingModel $bookingModel;
    private SessionModel $sessionModel;
    private PhotoModel $photoModel;

    public function __construct()
    {
        $this->bookingModel = new BookingModel();
        $this->sessionModel = new SessionModel();
        $this->photoModel = new PhotoModel();
    }

    public function start(): ResponseInterface
    {
        $payload = $this->request->getJSON(true) ?? $this->request->getPost();

        $bookingId = trim((string) ($payload['booking_id'] ?? ''));
        $frameId   = trim((string) ($payload['frame_id'] ?? ''));
        $filterId  = trim((string) ($payload['filter_id'] ?? ''));

        if ($bookingId === '' || $frameId === '' || $filterId === '') {
            return $this->failValidation('booking_id, frame_id, dan filter_id wajib diisi.');
        }

        $booking = $this->bookingModel->find($bookingId);

        if ($booking === null) {
            return $this->failNotFound('Booking tidak ditemukan.');
        }

        if ($booking['status'] !== 'paid') {
            return $this->failValidation('Session hanya bisa dimulai setelah pembayaran sukses.');
        }

        $session = $this->sessionModel
            ->where('booking_id', $bookingId)
            ->first();

        if ($session === null) {

            $session = [
                'id'               => $this->makeId('ses_'),
                'booking_id'       => $bookingId,
                'frame_id'         => $frameId,
                'filter_id'        => $filterId,
                'email_recipient'  => '',
                'drive_folder_url' => '',
            ];

            $this->sessionModel->insert($session);

            $session = $this->sessionModel->find($session['id']);
        } else {

            $this->sessionModel->update($session['id'], [
                'frame_id'  => $frameId,
                'filter_id' => $filterId,
            ]);

            $session = $this->sessionModel->find($session['id']);
        }

        return $this->respondOk([
            'message' => 'Session siap. Lanjut countdown dan capture.',
            'session' => $session,
            'capture_rules' => [
                'target_shots'             => 10,
                'timer_seconds_per_shot'   => 15,
                'preview_timeout_seconds'  => 420,
            ],
        ]);
    }

    public function upload(string $sessionId): ResponseInterface
    {
        $session = $this->sessionModel->find($sessionId);

        if ($session === null) {
            return $this->failNotFound('Session tidak ditemukan.');
        }
        // Hapus metadata foto lama jika user upload ulang
        $this->photoModel
            ->where('session_id', $sessionId)
            ->delete();

        // photostrip final
        $finalImage = $this->request->getFile('final_image');

        if (!$finalImage || !$finalImage->isValid()) {
            return $this->failValidation('Final image wajib dikirim.');
        }

        // seluruh hasil capture
        $capturedPhotos = $this->request->getFileMultiple('captured_photos');

        // fallback apabila FE mengirim captured_photos[]
        if (empty($capturedPhotos)) {
            $capturedPhotos = $this->request->getFileMultiple('captured_photos[]');
        }

        if (!is_array($capturedPhotos)) {
            $capturedPhotos = [];
        }

        $folder = WRITEPATH . 'uploads/sessions/' . $sessionId;

        if (!is_dir($folder)) {
            mkdir($folder, 0777, true);
        }

        // simpan photostrip
        $finalImage->move(
            $folder,
            'final.png',
            true
        );

        $this->photoModel->insert([
            'id'            => $this->makeId('pho_'),
            'session_id'    => $sessionId,
            'file_path'     => 'uploads/sessions/' . $sessionId . '/final.png',
            'drive_file_id' => '',
            'shot_number'   => 0,
        ]);

        // simpan video transisi jika ada
        $finalVideoTransition = $this->request->getFile('final_video_transition');
        if ($finalVideoTransition && $finalVideoTransition->isValid()) {
            $ext = $finalVideoTransition->getExtension();
            $transitionFilename = 'final_video_transition.' . $ext;
            $finalVideoTransition->move(
                $folder,
                $transitionFilename,
                true
            );
            $this->photoModel->insert([
                'id'            => $this->makeId('pho_'),
                'session_id'    => $sessionId,
                'file_path'     => 'uploads/sessions/' . $sessionId . '/' . $transitionFilename,
                'drive_file_id' => '',
                'shot_number'   => 999, // 999 for transition video
            ]);
        }

        // simpan video loop jika ada
        $finalVideoLoop = $this->request->getFile('final_video_loop');
        if ($finalVideoLoop && $finalVideoLoop->isValid()) {
            $ext = $finalVideoLoop->getExtension();
            $loopFilename = 'final_video_loop.' . $ext;
            $finalVideoLoop->move(
                $folder,
                $loopFilename,
                true
            );
            $this->photoModel->insert([
                'id'            => $this->makeId('pho_'),
                'session_id'    => $sessionId,
                'file_path'     => 'uploads/sessions/' . $sessionId . '/' . $loopFilename,
                'drive_file_id' => '',
                'shot_number'   => 998, // 998 for loop video
            ]);
        }

        $savedCaptures = [];

        foreach ($capturedPhotos as $index => $photo) {

            if (!$photo || !$photo->isValid()) {
                continue;
            }

            $filename = 'capture_' .
                ($index + 1) .
                '.' .
                $photo->getExtension();

            $photo->move(
                $folder,
                $filename,
                true
            );

            $this->photoModel->insert([
                'id'            => $this->makeId('pho_'),
                'session_id'    => $sessionId,
                'file_path'     => 'uploads/sessions/' . $sessionId . '/' . $filename,
                'drive_file_id' => '',
                'shot_number'   => $index + 1,
            ]);

            $savedCaptures[] = $filename;
        }

        // logging untuk debugging
        log_message('debug', '=== SESSION UPLOAD ===');
        log_message('debug', 'Session : ' . $sessionId);
        log_message('debug', 'Final   : final.png');
        log_message('debug', 'Capture : ' . count($savedCaptures));

        return $this->respondOk([
            'message'         => 'Upload berhasil.',
            'session_id'      => $sessionId,
            'final_image'     => 'final.png',
            'captured_count'  => count($savedCaptures),
            'captured_files'  => $savedCaptures,
            'photos_saved'    => $this->photoModel
                ->where('session_id', $sessionId)
                ->countAllResults(),
        ]);
    }

    public function uploadLive(string $sessionId): ResponseInterface
    {
        $session = $this->sessionModel->find($sessionId);

        if ($session === null) {
            return $this->failNotFound('Session tidak ditemukan.');
        }

        // Hapus metadata live photo lama jika user upload ulang
        $this->photoModel
            ->where('session_id', $sessionId)
            ->where('shot_number >=', 100)
            ->delete();

        // live photos (secret videos)
        $livePhotos = $this->request->getFileMultiple('live_photos');
        if (empty($livePhotos)) {
            $livePhotos = $this->request->getFileMultiple('live_photos[]');
        }
        if (!is_array($livePhotos)) {
            $livePhotos = [];
        }

        $folder = WRITEPATH . 'uploads/sessions/' . $sessionId;
        if (!is_dir($folder)) {
            mkdir($folder, 0777, true);
        }

        $savedLivePhotos = [];
        foreach ($livePhotos as $index => $livePhoto) {
            if (!$livePhoto || !$livePhoto->isValid()) {
                continue;
            }

            $liveFilename = 'live_' .
                ($index + 1) .
                '.' .
                $livePhoto->getExtension();

            $livePhoto->move(
                $folder,
                $liveFilename,
                true
            );

            $this->photoModel->insert([
                'id'            => $this->makeId('pho_'),
                'session_id'    => $sessionId,
                'file_path'     => 'uploads/sessions/' . $sessionId . '/' . $liveFilename,
                'drive_file_id' => '',
                'shot_number'   => 100 + ($index + 1),
            ]);

            $savedLivePhotos[] = $liveFilename;
        }

        // logging untuk debugging
        log_message('debug', '=== SESSION LIVE UPLOAD ===');
        log_message('debug', 'Session : ' . $sessionId);
        log_message('debug', 'Live    : ' . count($savedLivePhotos));

        return $this->respondOk([
            'message'         => 'Upload live photo berhasil.',
            'session_id'      => $sessionId,
            'live_count'      => count($savedLivePhotos),
            'live_files'      => $savedLivePhotos,
            'photos_saved'    => $this->photoModel
                ->where('session_id', $sessionId)
                ->countAllResults(),
        ]);
    }

    public function submitEmail(string $sessionId): ResponseInterface
    {
        $session = $this->sessionModel->find($sessionId);

        if ($session === null) {
            return $this->failNotFound('Session tidak ditemukan.');
        }

        $payload = $this->request->getJSON(true) ?? $this->request->getPost();

        $email = trim((string) ($payload['email'] ?? ''));

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return $this->failValidation('Format email tidak valid.');
        }

        $this->sessionModel->update($sessionId, [
            'email_recipient' => $email,
        ]);

        return $this->respondOk([
            'message' => 'Email penerima disimpan.',
            'session_id' => $sessionId,
            'email' => $email,
        ]);
    }

    public function complete(string $sessionId): ResponseInterface
    {
        set_time_limit(300);

        $session = $this->sessionModel->find($sessionId);

        if ($session === null) {
            return $this->failNotFound('Session tidak ditemukan.');
        }

        if (trim((string) $session['email_recipient']) === '') {
            return $this->failValidation('Email penerima belum diisi.');
        }

        $booking = $this->bookingModel->find($session['booking_id']);

        if ($booking === null) {
            return $this->failNotFound('Booking tidak ditemukan.');
        }

        if ($booking['status'] !== 'paid') {
            return $this->failValidation('Booking belum paid.');
        }

        try {
            // Jalankan proses upload drive & kirim email di background agar respons instan
            $command = "start /B \"\" \"" . PHP_BINARY . "\" \"" . FCPATH . "../spark\" session:complete " . escapeshellarg($sessionId) . " > NUL 2>&1";
            pclose(popen($command, "r"));

            return $this->respondOk([
                'message' => 'Flow selesai (diproses di background).',
                'booking_id' => $booking['id'],
                'session_id' => $sessionId,
                'next_step' => 'reset',
            ]);
        } catch (\Throwable $e) {

            log_message('error', $e->getMessage());

            return $this->failServerError(
                $e->getMessage()
            );
        }
    }

    public function captureDslr(string $sessionId): ResponseInterface
    {
        $session = $this->sessionModel->find($sessionId);
        if ($session === null) {
            return $this->failNotFound('Session tidak ditemukan.');
        }

        // Tentukan folder temporary publik
        $tempFolder = FCPATH . 'uploads/temp/';
        if (!is_dir($tempFolder)) {
            mkdir($tempFolder, 0777, true);
        }

        $outputFile = $tempFolder . 'dslr_' . $sessionId . '_' . time() . '.jpg';
        $outputFileWin = str_replace('/', '\\', $outputFile);

        // Cek apakah web server digiCamControl aktif (port 5513)
        $webServerUrl = 'http://127.0.0.1:5513';
        $isWebServerActive = false;
        
        $connection = @fsockopen('127.0.0.1', 5513, $errno, $errstr, 0.5);
        if ($connection) {
            fclose($connection);
            $isWebServerActive = true;
        }

        if ($isWebServerActive) {
            $ctx = stream_context_create([
                'http' => [
                    'timeout' => 3.0, // 3.0 detik timeout untuk transfer file/capture
                ]
            ]);

            // Dapatkan nama file jepretan sebelumnya sebelum memicu shutter
            $lastCapturedUrl = $webServerUrl . '/?slc=get&param1=lastcaptured&param2=';
            $previousFilename = '';
            $prevRes = @file_get_contents($lastCapturedUrl, false, $ctx);
            if ($prevRes !== false) {
                $previousFilename = trim($prevRes);
            }

            // 1. Pemicu jepret via Web Server API (?slc=capture)
            $captureUrl = $webServerUrl . '/?slc=capture';
            $captureResult = @file_get_contents($captureUrl, false, $ctx);
            
            // 2. Poll untuk nama file terakhir yang baru (harus berbeda dengan file sebelumnya)
            $filename = '';
            $maxPoll = 150; // maks 15 detik (150 * 100ms)
            
            for ($i = 0; $i < $maxPoll; $i++) {
                $res = @file_get_contents($lastCapturedUrl, false, $ctx);
                if ($res !== false) {
                    $resClean = trim($res);
                    // Harus tidak empty, bukan "-", dan tidak sama dengan jepretan sebelumnya
                    if ($resClean !== '-' && !empty($resClean) && $resClean !== $previousFilename) {
                        $filename = $resClean;
                        break;
                    }
                }
                usleep(100000); // 100ms (0.1 detik)
            }
            
            if (empty($filename)) {
                return $this->failServerError('Gagal mendeteksi file foto setelah trigger capture via Web Server. Pastikan kamera menyala dan terhubung di digiCamControl.');
            }
            
            // 3. Download file gambar dari Web Server
            $imageUrl = $webServerUrl . '/image/' . rawurlencode($filename);
            $imageContent = @file_get_contents($imageUrl, false, $ctx);
            
            if ($imageContent === false || empty($imageContent)) {
                return $this->failServerError('Gagal mengunduh foto ' . $filename . ' dari web server digiCamControl.');
            }
            
            // Simpan gambar ke folder temp
            file_put_contents($outputFile, $imageContent);
        } else {
            // Tentukan path CameraControlCmd.exe
            $cmdPath = 'C:\\Program Files (x86)\\digiCamControl\\CameraControlCmd.exe';
            if (!file_exists($cmdPath)) {
                $cmdPath = 'C:\\Program Files\\digiCamControl\\CameraControlCmd.exe';
            }

            if (!file_exists($cmdPath)) {
                return $this->failServerError('Aplikasi digiCamControl tidak terdeteksi (Web Server mati dan CameraControlCmd.exe tidak ditemukan). Silakan jalankan digiCamControl.');
            }

            // Siapkan perintah cmd untuk digiCamControl
            $cmd = '"' . $cmdPath . '" /capture /filename "' . $outputFileWin . '"';

            // Jalankan perintah
            $output = shell_exec($cmd);

            // Verifikasi hasil file
            if (!file_exists($outputFile) || filesize($outputFile) === 0) {
                return $this->failServerError('Gagal menjepret foto dengan DSLR via CLI. Pastikan kamera menyala, terhubung via USB, dan tidak terkunci oleh aplikasi lain. Detail: ' . $output);
            }
        }

        $fileUrl = base_url('uploads/temp/' . basename($outputFile));

        // Generate lower resolution preview (GD library) for instant kiosk loading
        $previewUrl = $fileUrl; // Fallback to original URL
        try {
            if (extension_loaded('gd') && file_exists($outputFile)) {
                $srcImg = @imagecreatefromjpeg($outputFile);
                if ($srcImg) {
                    $srcW = imagesx($srcImg);
                    $srcH = imagesy($srcImg);
                    
                    // Target width 1024px for quick loading preview
                    $targetW = 1024;
                    $targetH = (int)($srcH * ($targetW / $srcW));
                    
                    $previewImg = imagecreatetruecolor($targetW, $targetH);
                    
                    // Resample image
                    imagecopyresampled($previewImg, $srcImg, 0, 0, 0, 0, $targetW, $targetH, $srcW, $srcH);
                    
                    // Save preview file
                    $previewFile = $tempFolder . 'prev_' . basename($outputFile);
                    @imagejpeg($previewImg, $previewFile, 70); // quality 70 is perfect for instant kiosk preview
                    
                    imagedestroy($srcImg);
                    imagedestroy($previewImg);
                    
                    if (file_exists($previewFile)) {
                        $previewUrl = base_url('uploads/temp/' . basename($previewFile));
                    }
                }
            }
        } catch (\Throwable $e) {
            log_message('error', 'Gagal membuat pratinjau DSLR: ' . $e->getMessage());
        }

        return $this->respondOk([
            'status' => true,
            'message' => 'DSLR capture success',
            'data' => [
                'image_url' => $fileUrl,
                'preview_url' => $previewUrl,
                'filename' => basename($outputFile),
            ]
        ]);
    }

    public function getTempPhoto(string $filename)
    {
        $path = FCPATH . 'uploads/temp/' . $filename;
        if (!file_exists($path)) {
            return $this->failNotFound('Photo not found');
        }

        $mime = mime_content_type($path) ?: 'image/jpeg';

        return $this->response
            ->setHeader('Content-Type', $mime)
            ->setBody(@file_get_contents($path));
    }

    public function startLiveView()
    {
        $webServerUrl = 'http://127.0.0.1:5513';
        
        // 1. Cek koneksi port 5513 dengan timeout cepat (0.5s) agar PHP tidak hang
        $connection = @fsockopen('127.0.0.1', 5513, $errno, $errstr, 0.5);
        if (!$connection) {
            return $this->respondOk([
                'status' => false,
                'message' => 'digiCamControl web server is offline (port 5513). Live view cannot start.',
                'response' => false
            ]);
        }
        fclose($connection);

        // 2. Set context timeout untuk file_get_contents
        $ctx = stream_context_create([
            'http' => [
                'timeout' => 1.5, // 1.5 detik timeout
            ]
        ]);

        $res = @file_get_contents($webServerUrl . '/?CMD=LiveViewWnd_Show', false, $ctx);
        
        // Wait 300ms, then minimize all digiCamControl windows so it stays in background
        usleep(300000);
        @file_get_contents($webServerUrl . '/?CMD=All_Minimize', false, $ctx);

        return $this->respondOk([
            'status' => true,
            'message' => 'Live view started and minimized',
            'response' => $res
        ]);
    }

    public function stopLiveView()
    {
        $webServerUrl = 'http://127.0.0.1:5513';

        // 1. Cek koneksi port 5513 dengan timeout cepat (0.5s) agar PHP tidak hang
        $connection = @fsockopen('127.0.0.1', 5513, $errno, $errstr, 0.5);
        if (!$connection) {
            return $this->respondOk([
                'status' => false,
                'message' => 'digiCamControl web server is offline (port 5513). Live view cannot stop.',
                'response' => false
            ]);
        }
        fclose($connection);

        // 2. Set context timeout untuk file_get_contents
        $ctx = stream_context_create([
            'http' => [
                'timeout' => 1.5, // 1.5 detik timeout
            ]
        ]);

        $res = @file_get_contents($webServerUrl . '/?CMD=LiveViewWnd_Hide', false, $ctx);
        return $this->respondOk([
            'status' => true,
            'message' => 'Live view stopped',
            'response' => $res
        ]);
    }
}
